# Demi OS version pre-alpha demo
import time
eratatas = False
count = 0
fourty = 0
Bored = open('setup//DAT.txt', 'r')
DATT = Bored.read()
files = (DATT)
try:
    ouch = open(files,'r')
    file1 = ouch.read()
except FileNotFoundError:
    eratatas = True
if eratatas != True:
    lines = []
    with open(DATT) as f:
        lines = f.readlines()
    count = 0
# The following was an example I needed.
# for line in lines:
    # count += 1
    # print(f'line {count}: {line}')
    for line in lines:
        fourty = 40
        break
    if fourty == 40:
        pie = 0
        file1 = False
        print('Directories have been found.')
        print('')
        print('Please choose which directory you would like to use')
        print('')
        for line in lines:
            print(f'{count}. {line}')
            count += 1
            print('')
            print('-1. Use custom file path')
            print('')
            try:
                hahh = int(input('>_'))
                if hahh == -1:
                    print('')
                    pie = 0
                    vary = 0
                if hahh == 0:
                    never = (lines[0])
                    foo = never.replace('\n', '')
                    pie = 1
                    ooga = 1
                if hahh == 1:
                    never = (lines[1])
                    foo = never.replace('\n', '')
                    pie = 1
                    ooga = 1
                if hahh == 2:
                    never = (lines[2])
                    foo = never.replace('\n', '')
                    pie = 1
                    ooga = 1
                if hahh == 3:
                    never = (lines[3])
                    foo = never.replace('\n', '')
                    pie = 1
                    ooga = 1
                if hahh == 4:
                    never = (lines[4])
                    foo = never.replace('\n', '')
                    pie = 1
                    ooga = 1
                if hahh == 5:
                    never = (lines[5])
                    foo = never.replace('\n', '')
                    pie = 1
                    ooga = 1
                if hahh == 6:
                    never = (lines[6])
                    foo = never.replace('\n', '')
                    pie = 1
                    ooga = 1
                if hahh == 7:
                    never = (lines[7])
                    foo = never.replace('\n', '')
                    pie = 1
                    ooga = 1
                if hahh == 8:
                    never = (lines[8])
                    foo = never.replace('\n', '')
                    pie = 1
                    ooga = 1
                if hahh == 9:
                    never = (lines[9])
                    foo = never.replace('\n', '')
                    pie = 1
                    ooga = 1
                if hahh == 10:
                    never = (lines[10])
                    foo = never.replace('\n', '')
                    pie = 1
                    ooga = 1
            except IndexError:
                print('')
                print(f'Err: Directory at {hahh} was not found!')
                baz = input('Type anything & enter to exit... ')
                exit()
            except ValueError:
                print('')
                print(f'Err: User response cannot be a str or float type. Only a int/num type!')
                baz = input('Type anything & enter to exit... ')
                exit()
            except:
                print('Err: Unknown')
try:     
    if ooga == 1:
        zezzy = 5
        zazzy = 2
except NameError:
    try:
        if hahh != -1:
            print('')
            print('Fatal Error: Path specified does not exist!')
            baz = input('Type anything & enter to exit... ')
            exit()
    except NameError:
        fiurgkgkjderreijo = '29i34328'
        print('')
    pie = 0
while 1 < 2:
    time.sleep(0.2)
    if pie != 1:
        print('Please input .txt directory (Ex. C://Hello.txt)')
        print('')
        pie = 1
        foo = input('>_')
        hm = ('C:' in foo)
        if hm == False:
            hm = ('D:' in foo)
        if hm == False:
            print('')
            print("The path you are trying to give may not exist, a new '.file' file will be created with the name of the path you just entered. To read the contents of this new file you may convert the file extension to '.txt'.")
    print('')
    print('Would you like to read or write?')
    print(' 0. Read')
    print(' 1. Write')
    print(' 2. Append')
    print(' 3. Append New Line(After)')
    print(' 4. Append New Line(Before)')
    print(' 5. Append New Line(Before and After)')
    print(' 6. Clear Text File')
    print(' 7. Exit')
    print('')
    try:
        barz = int(input('>_'))
        if barz == 0:
            print('')
            r = open(foo,'r')
            contents = r.read()
            print(contents)
            r.close()
        if barz == 1:
            print('')
            print('Type contents here')
            print('')
            hehe = input('>_')
            w = open(foo,'w')
            w.write(hehe)
            w.close()
        if barz == 2:
            print('')
            print('Type append here')
            print('')
            hehe = input('>_')
            a = open(foo,'a')
            a.write(hehe)
            a.close()
        if barz == 3:
            print('')
            print('Type append here')
            print('')
            hehe = input('>_')
            a = open(foo,'a')
            a.write(hehe + '\n')
            a.close()
        if barz == 4:
            print('')
            print('Type append here')
            print('')
            hehe = input('>_')
            a = open(foo,'a')
            a.write('\n' + hehe)
            a.close()
        if barz == 5:
            print('')
            print('Type append here')
            print('')
            hehe = input('>_')
            a = open(foo,'a')
            a.write('\n' + hehe + '\n')
            a.close()
        if barz == 6:
            print('')
            c = open(foo,'w')
            c.write('')
            c.close()
            print('Text file cleared!')
        if barz == 7:
            print('')
            print('Goodbye!')
            baz = input('Type anything & enter to exit... ')
            vary = 1
            break
    except PermissionError:
        print('')
        print("Err: Either given path doesn't exist or permissions are not allowed to access said path. Or the file type isn't '.txt'.")
        baz = input('Type anything & enter to exit... ')
        exit()
    except FileNotFoundError:
        print('')
        print("Err: File not found.")
        baz = input('Type anything & enter to exit... ')
        exit()
    except ValueError:
        print('')
        print('Err: Only int/num values are allowed for this prompt. Str/Float are not valid!')
        baz = input('Type anything & enter to exit... ')
        exit()
if vary != 1:
    print('A fatal error has occured')
    baz = input('Type anything & enter to exit... ')
exit()
