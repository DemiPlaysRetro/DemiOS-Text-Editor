import time
import os
print('Welcome to | DemiOS: Text Editor | Setup!')
print('')
print('Do you already have a txt file of your preset txt file paths? (Must be named preexisting.txt!)?')
print(' 0. No, create one.')
print(' 1. Yes!')
a = int(input('>_'))
if a == 1:
    print('')
    print('Please enter your txt file for your list of saved txt file directories.')
    b = input('>_')
    try:
        with open(b, 'r') as f:
            f.read()
    except FileNotFoundError:
        print('')
        print("We couldn't find your file sorry :(")
        exit()
    try:
        with open('DAT.txt', 'x') as n:
            n.write(b)
            print('')
            print('Your path has been successfully set!')
            exit()
    except FileExistsError:
        print('')
        print('Set path exists, would you like to overwrite?')
        print(' 0. Yes')
        print(' 1. No')
        c = int(input('>_'))
        if c == 0:
            os.remove("DAT.txt")
            with open('DAT.txt', 'x') as j:
                j.write(b)
                print('')
                print('Your path has been successfully set.')
                exit()
        if c == 1:
            print('')
            print('Alright, bye then!')
            exit()
if a == 0:
    try:
        with open('preexisting.txt', 'x') as g:
            g.write('')
    except FileExistsError:
        print("Uhm, you already have a preexisting.txt file. Why did you say you didn't? Dirty liar >:(")
        exit()
    with open('DAT.txt', 'x') as o:
        o.write('setup//' + 'preexisting.txt')
        print('')
        print('Your file has been created, Enjoy!')
